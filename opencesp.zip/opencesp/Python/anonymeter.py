def singling_out(orig_train, orig_ho, synth, n_attacks):
	from anonymeter.evaluators import SinglingOutEvaluator
	ev=SinglingOutEvaluator(ori=orig_train, syn=synth, control=orig_ho, n_attacks=int(n_attacks))
	ev.evaluate()
	return ev.risk().value

def linkability(orig_train, orig_ho, synth, aux_cols, target_cols, n_attacks):
	from anonymeter.evaluators import LinkabilityEvaluator
	ev=LinkabilityEvaluator(ori=orig_train, syn=synth, control=orig_ho, aux_cols=aux_cols, n_attacks=int(n_attacks))
	ev.evaluate()
	return ev.risk().value

def inference(orig_train, orig_ho, synth, aux_cols, target_cols, n_attacks):
	from anonymeter.evaluators import InferenceEvaluator
	ev=InferenceEvaluator(ori=orig_train, syn=synth, control=orig_ho, aux_cols=aux_cols, secret=target_cols, n_attacks=int(n_attacks))
	ev.evaluate()
	return ev.risk().value