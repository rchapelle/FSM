#' TODO
save_plot <- function(dir, width=7, height=5.5, p = NULL) {
  files <- list.files(path = dir, pattern = "plot[0-9]+\\.jpg", full.names = FALSE)
  n <- as.numeric(gsub("plot([0-9]+)\\.jpg", "\\1", files))
  if (length(n) > 0) max_n <- max(n, na.rm = TRUE)
  else max_n <- 0
  if(is.null(p)) p <- ggplot2::last_plot()
  filename <- paste(dir, "/plot", max_n + 1, ".jpg", sep="")
  ggsave(file = filename, plot = p,
         width = width, height = height, dpi = 320)
  return(filename)
}



#' TODO
borelli_theme <- function(rotate_x_labs = FALSE, show_title = FALSE, legend_pos = NULL) {
  res <- theme_bw() +
    theme(
      axis.text = ggplot2::element_text(size = 14, color = "black", family = "sans"),
      axis.text.x = if(rotate_x_labs) ggplot2::element_text(angle = 90, vjust = 0.5, hjust = 1)
      else NULL,
      axis.title = ggplot2::element_text(size = 17, color = "black", family = "sans"),
      axis.title.x = ggplot2::element_text(margin = ggplot2::margin(t = 16)),
      axis.title.y = ggplot2::element_text(margin = ggplot2::margin(r = 16)),
      legend.text = ggplot2::element_text(size = 14, color = "black", family = "sans"),
      legend.background = ggplot2::element_rect(fill = "white", color = "grey"),
      legend.title = if(show_title) element_text(size = 16, color = "black", family = "sans", margin = margin(b = 10))
      else ggplot2::element_blank(),
      legend.key.spacing.y = ggplot2::unit(0.6, "lines"),
      panel.spacing = ggplot2::unit(0.8, "lines"),
      strip.placement = "outside",
      strip.background = ggplot2::element_rect(fill="white", colour = "white"),
      strip.text.y = ggplot2::element_text(size = 17, color = "black", family = "sans")
    )
  if(!is.null(legend_pos) && legend_pos == "bottomright") {
    res <- res +
      theme(
        legend.position = "inside",
        legend.position.inside = c(0.95, 0.05),
        legend.justification = c("right", "bottom")
      )
  }
  else if(!is.null(legend_pos) && legend_pos == "topright") {
    res <- res +
      theme(
        legend.position = "inside",
        legend.position.inside = c(0.95, 0.95),
        legend.justification = c("right", "top")
      )
  }
  else if(!is.null(legend_pos) && legend_pos == "topleft") {
    res <- res +
      theme(
        legend.position = "inside",
        legend.position.inside = c(0.05, 0.95),
        legend.justification = c("left", "top")
      )
  }
  return(res)
}



#' TODO
bor_cols <- function() {
  c("#534785", "#f55f5e", "#EAD94C", "#51A3A3", "#82846D", "#A1C084", "#754F5B","#27476E", "#EB9486")
}



#' Lines or spaghetti plot
#'
#' @description
#' `spaghetti_RU` creates a plot which visualizes the relationship between a risk variable and one or more utility variables in a dataframe.
#' If there is only one utility variable, it simply connects the points using line segments.
#' If there are multiple other variables, it plots each pair (risk_var, util_N) as a spaghetti plot.
#'
#' @param data A dataframe containing the data to be plotted.
#' @param risk_var The name of the risk variable in the dataframe.
#' @param title The title of the plot.
#' @param risk_lab The desired label for the risk axis.
#' @param util_lab The desired label for the utility axis.
spaghetti_RU <- function(data, risk_var, title=NULL, risk_lab=NULL, util_lab=NULL) {
  if (!risk_var %in% names(data)) {
    stop("Specified risk var cannot be found.")
  }
  other_vars <- setdiff(names(data), risk_var)
  if (length(other_vars) == 1) {
    data_sorted <- data[order(data[[other_vars]]), ]
    plot(data_sorted[[other_vars]], data_sorted[[risk_var]], type = "l", main = title,
         xlab = util_lab, ylab = risk_lab, col = "blue")
  }
  else {
    plot(NULL, xlim = range(data[risk_var], na.rm = TRUE), ylim = range(data[other_vars], na.rm = TRUE),
         xlab = risk_lab, ylab = util_lab, main = title)

    i <- 1
    colors <- rainbow(length(other_vars))
    data_sorted <- data[order(data[[risk_var]]), ]
    for (var in other_vars) {
      lines(data_sorted[[risk_var]], data_sorted[[var]], col = colors[i])
      i <- i + 1
    }
    mean_line <- rowMeans(data_sorted[other_vars], na.rm = TRUE)
    lines(data_sorted[[risk_var]], mean_line, col = "red", lwd = 3)

    legend("bottomright", legend = c(other_vars, "Mean"), col = c(colors, "red"), lwd = c(rep(1, length(other_vars)), 3))
  }
}
