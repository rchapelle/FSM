#' Proportion of exact matches
#'
#' @description
#' `get_matches_prop` returns the proportion of rows in an original dataframe which can be found as-is in a
#' synthetic dataframe. Duplicates within each dataframe are treated as a single record. TODO
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The obtained proportion.
get_matches_prop <- function(orig, synth, method = "exact", thr = NULL) {
  if(method == "exact") { #TODO contrôle paramètres
    orig <- dplyr::distinct(orig)
    synth <- dplyr::distinct(synth)
    common <- dplyr::inner_join(orig, synth, by = colnames(orig))
    return(nrow(common) / nrow(orig))
  }
  else if(method == "euclidean") {
    common <- rbind(synth, orig)
    common <- (common - min(common, na.rm = TRUE)) / (max(common, na.rm = TRUE) - min(common, na.rm = TRUE))
    do <- as.matrix(dist(common, method = "euclidean"))
    orig_indices <- (nrow(synth) + 1):nrow(common)
    min_dists <- apply(do[orig_indices, 1:nrow(synth), drop = FALSE], 1, min)
    return(sum(min_dists < thr) / length(min_dists))
  }
  else if(method == "gower") {
    common <- rbind(synth, orig)
    do <- as.matrix(cluster::daisy(common, metric = "gower"))
    orig_indices <- (nrow(synth) + 1):nrow(common)
    min_dists <- apply(do[orig_indices, 1:nrow(synth), drop = FALSE], 1, min)
    return(sum(min_dists < thr) / length(min_dists))
  }
}



#' Distance to the closest record
#'
#' @description
#' `get_dcr` returns the average Gower's distance between each synthetic unit and its nearest
#' original neighbor. This type of metric was namely suggested in https://doi.org/10.14778/3231751.3231757.
#' Here we use Gower's distance to account for mixed data types (see for example https://doi.org/10.48550/arXiv.2101.02481). #TODO
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#' @param n_cores The number of logical processes to use for the computation. If set to NULL, the function will
#' attempt to determine the number of physical cores on the device and use this number, minus one.
#'
#' @return The average distance.
get_dcr <- function(orig, synth, method = "gower", n_cores=NULL) {
    if(is.null(n_cores)) n_cores <- parallel::detectCores() - 1

    if(method == "gower") { # TODO : ordre entre gower et euclidean (cf. supra)
      common <- rbind(synth, orig)
      do <- as.matrix(cluster::daisy(common, metric = "gower")) # "do" stands for "dissimilarity object"
    }
    else if(method == "euclidean") { # TODO : contrôle des paramètres (variables numériques, méthode autorisée)
      common <- rbind(synth, orig)
      common <- (common - min(common, na.rm = TRUE)) / (max(common, na.rm = TRUE) - min(common, na.rm = TRUE))
      do <- as.matrix(dist(common, method = "euclidean"))
    }

    process_rows <- function(synth_idx) {
      orig_indices <- (nrow(synth) + 1):(nrow(synth) + nrow(orig))
      min_dists <- apply(do[synth_idx, orig_indices, drop = FALSE], 1, min)
      return(min_dists)
    }

    if(n_cores == 1) {
      return(mean(process_rows(1:nrow(synth))))
    }

    cluster <- parallel::makeCluster(n_cores)
    on.exit(parallel::stopCluster(cluster))
    parallel::clusterExport(cluster, list("synth", "do", "n_cores", "process_rows"), envir=environment())
    synth_indices <- split(1:nrow(synth), cut(1:nrow(synth), n_cores, labels = FALSE))
    dist_lists <- parallel::parLapply(cluster, synth_indices, process_rows)
    dist_list <- unlist(dist_lists)
    return(mean(dist_list))
}



#' Minimum Hamming distance
#'
#' @description
#' `get_min_hamming` returns the Hamming distance between an element and its nearest neighbor in a dataframe.
#'
#' @param e A character vector representing a statistical unit.
#' @param df A dataframe with the same variables as e, not necessarily containing e.
#'
#' @return The minimum distance.
get_min_hamming <- function(e, df) {
  manage_NA <- function(vec) {
    vec[vec == "NA"] <- "\\NA"
    vec[is.na(vec)] <- "NA"
    vec
  }
  e <- manage_NA(e)
  df_mod <- as.data.frame(lapply(df, manage_NA))
  dists <- rowSums(as.matrix(df_mod) != matrix(e, nrow = nrow(df_mod), ncol = length(e), byrow = TRUE))
  min(dists)
}



#' Membership F1 metric
#'
#' @description
#' `get_cor_F1` returns a corrected F1 membership disclosure metric, as described in
#' https://doi.org/10.1093/jamiaopen/ooac083.
#'
#' @param orig_train A subset of the original dataframe to use for training.
#' @param orig_ho The hold-out subset of the original dataframe, with the same variables as orig_train.
#' @param synth A dataframe containing synthetic data, with the same variables as orig_train and orig_ho.
#' @param m The desired number of records in the attack dataset.
#' @param t The desired proportion of records of the attack dataset originating from orig_train. #TODO order
#' @param h The Hamming distance threshold to use.
#' @param N The size of the source population from which original data originate.
#'
#' @return The membership disclosure metric, or NA if the F1 score is undefined.
get_cor_F1 <- function(orig_train, orig_ho, synth, m, h, N, t = (nrow(orig_train) + nrow(orig_ho)) / N) {
  D <- rbind(dplyr::sample_n(orig_train, m*t), dplyr::sample_n(orig_ho, m*(1-t)))
  synth_mod <- as.data.frame(lapply(synth, function(x) {
    x[x == "NA"] <- "\\NA"
    x[is.na(x)] <- "NA"
    x
  }))
  synth_mat <- as.matrix(synth_mod)
  D_mat <- as.matrix(D)
  get_min <- function(y) {
    y <- as.character(y)
    dists <- rowSums(synth_mat != matrix(y, nrow = nrow(synth_mat), ncol = length(y), byrow = TRUE))
    min(dists)
  }
  min_ham <- apply(D_mat, 1, get_min)
  print(min_ham) #TODO
  match_list <- ifelse(min_ham < h, 1, 0)
  n_matched <- sum(match_list)
  vp <- sum(match_list[1:(m*t)])
  precision <- vp/n_matched
  recall <- vp/(m*t)
  F_val <- 2*precision*recall/(precision+recall)
  n <- nrow(orig_train)+nrow(orig_ho)
  F_max <- 2*n/(N/(1+n/N))
  (F_val-F_max)/(1-F_max)
}




#' Initialization of the Python environment
#'
#' @description
#' `init_python` initializes the Python environment to be used with this R session.
#'
#' @param python_path The path to the Python executable to use.
init_python <- function(python_path) {
  reticulate::use_python(python_path, required = TRUE)
  if(!reticulate::py_module_available("anonymeter")) {
    reticulate::py_install("anonymeter")
  }
}



#' Singling out attacks performed using Anonymeter
#'
#' @description
#' `anonymeter_singling_out` returns the result of singling out attacks simulated using Anonymeter (see
#' https://doi.org/10.56553/popets-2023-0055 and https://github.com/statice/anonymeter).
#'
#' @param orig_train A subset of the original dataframe to use for training.
#' @param orig_ho The hold-out subset of the original dataframe, with the same variables as orig_train.
#' @param synth A dataframe containing synthetic data, with the same variables as orig_train and orig_ho.
#' @param n_attacks The number of attacks to perform.
#' @param python_path The path to the Python executable to use.
#'
#' @return The result of the attacks.
anonymeter_singling_out <- function(orig_train, orig_ho, synth, n_attacks, python_path) {
  init_python(python_path)
  reticulate::source_python(here::here("Python/anonymeter.py"))
  return(singling_out(orig_train, orig_ho, synth, n_attacks))
}



#' Linkability attacks performed using Anonymeter
#'
#' @description
#' `anonymeter_linkability` returns the result of linkability attacks simulated using Anonymeter (see
#' https://doi.org/10.56553/popets-2023-0055 and https://github.com/statice/anonymeter).
#'
#' @param orig_train A subset of the original dataframe to use for training.
#' @param orig_ho The hold-out subset of the original dataframe, with the same variables as orig_train.
#' @param synth A dataframe containing synthetic data, with the same variables as orig_train and orig_ho.
#' @param aux_cols A vector containing the name of the variables to use as auxiliary information.
#' @param target_cols A vector containing the name of the target variables.
#' @param n_attacks The number of attacks to perform.
#' @param python_path The path to the Python executable to use.
#'
#' @return The result of the attacks.
anonymeter_linkability <- function(orig_train, orig_ho, synth, aux_cols, target_cols, n_attacks, python_path) {
  init_python(python_path)
  reticulate::source_python(here::here("Python/anonymeter.py"))
  return(linkability(orig_train, orig_ho, synth, aux_cols, target_cols, n_attacks))
}



#' Inference attacks performed using Anonymeter
#'
#' @description
#' `anonymeter_inference` returns the result of inference attacks simulated using Anonymeter (see
#' https://doi.org/10.56553/popets-2023-0055 and https://github.com/statice/anonymeter).
#'
#' @param orig_train A subset of the original dataframe to use for training.
#' @param orig_ho The hold-out subset of the original dataframe, with the same variables as orig_train.
#' @param synth A dataframe containing synthetic data, with the same variables as orig_train and orig_ho.
#' @param aux_cols A vector containing the name of the variables to use as auxiliary information.
#' @param target_cols A vector containing the name of the target variables.
#' @param n_attacks The number of attacks to perform.
#' @param python_path The path to the Python executable to use.
#'
#' @return The result of the attacks.
anonymeter_inference <- function(orig_train, orig_ho, synth, aux_cols, target_cols, n_attacks, python_path) {
  init_python(python_path)
  reticulate::source_python(here::here("Python/anonymeter.py"))
  return(inference(orig_train, orig_ho, synth, aux_cols, target_cols, n_attacks))
}
