#' Avatarization of an observation in low dimension
#'
#' @description
#' `get_rd_avatar` returns the avatar corresponding to an original observation expressed in a low-dimensional space, as described in  10.1038/s41746-023-00771-5.
#'
#' @details
#' Avatarization being a stochastic process, this function does not necessarily give the same result for successive calls with the same parameters.
#' Nearest neighbors are determined with respect to their Euclidean distances.
#'
#' @param mat A matrix containing original data expressed in addTaskCallback low-dimensional space, where each row represents an observation.
#' @param orig_id The index (in mat) of the observation to avatarize.
#' @param k The number of nearest neighbors to consider.
#'
#' @return The resulting avatar in the low-dimensional space.
get_rd_avatar <- function(mat, orig_id, k) {
  mat_filt <- mat[-orig_id, ]
  target <- mat[orig_id, , drop=FALSE]
  knn <- FNN::get.knnx(data = mat_filt, query = target, k = k, algorithm="brute") #Les NN sont déterminés de façon exacte
  contribs_shuffled <- sample(1:k)
  if(any(knn$nn.dist==0)) {
    D <- rep(0, k)
    D[knn$nn.dist==0] <- 1
  }
  else {
    D <- 1 / as.vector(knn$nn.dist)
  }
  R <- rexp(k, rate = 1)
  C <- (1/2)^contribs_shuffled
  weights <- D * R * C
  weights <- weights / sum(weights)
  neighbor_data <- mat_filt[knn$nn.index[1,], , drop = FALSE]
  weighted <- neighbor_data * weights
  return(colSums(weighted))
}



#' Expected value of the avatarization of observations in low dimension
#'
#' @description
#' `get_expected_rd_avatars` returns a matrix containing expected values of avatars of original observations expressed in a low-dimensional space,
#' as described in  10.1038/s41746-023-00771-5.
#'
#' @details
#' Depending on the method selected, expected values are determined either using a Monte Carlo approach, or using a closed-form approximation.
#' Nearest neighbors are determined with respect to their Euclidean distances.
#'
#' @param rd_data A matrix containing original data expressed in a low-dimensional space, where each row represents an observation.
#' @param k The number of nearest neighbors to consider.
#' @param method Either "MC" or "CF", respectively refering to using a Monte Carlo or closed-form approximation approach.
#' @param n_iter The number of repeated samplings to perform for Monte Carlo simulations (this parameter is ignored with "CF" methods).
#' @param n_cores The number of logical processes to use for the calculations. If set to NULL, the function will
#' attempt to determine the number of physical cores on the device and use this number, minus one.
#'
#' @return A matrix containing expected avatars in the low-dimensional space.
get_expected_rd_avatars <- function(rd_data, k, method, n_iter=1, n_cores=1) {
  if(is.null(n_cores)) n_cores <- parallel::detectCores() - 1

  process_obs <- function(id_list) {

    get_expected_rd_avatar <- function(mat, orig_id, k, n_iter) {
      mat_filt <- mat[-orig_id, ]
      target <- mat[orig_id, , drop=FALSE]
      knn <- FNN::get.knnx(data = mat_filt, query = target, k = k, algorithm="brute") #Les NN sont déterminés de façon exacte
      mat_weights <- matrix(nrow=k, ncol=n_iter)
      nn_mat <- mat_filt[knn$nn.index[1,], , drop = FALSE]

      if(method == "MC") {
        contribs_mat <- (1/2)^(replicate(n_iter, sample(1:k)))
        i <- 1
        for(id in knn$nn.index[1,]) {
          contribs <- contribs_mat[i, ]
          rand_weights <- rexp(n_iter, rate = 1)
          weights_vec <- 1/knn$nn.dist[i] * contribs * rand_weights
          mat_weights[i, ] <- weights_vec
          i <- i+1
        }
        sum_cols <- colSums(mat_weights)
        norm_mat_weights <- sweep(mat_weights, MARGIN = 2, STATS = sum_cols, FUN = "/")
        res_ind <- t(norm_mat_weights) %*% nn_mat
        return(colMeans(res_ind))
      }
      else {
        weights <- numeric(k)
        for(i in 1:k) {
          contrib <- 1-((1/2)^k)/k
          weights[i] <- 1/knn$nn.dist[i] * contrib
        }
        weights <- weights / sum(weights)
        res_ind <- weights %*% nn_mat
        return(colMeans(res_ind))
      }
    }

    num_results <- length(id_list)
    results_matrix <- matrix(nrow = num_results, ncol = ncol(rd_data))
    rownames(results_matrix) <- id_list

    for(i in seq_along(id_list)) {
      orig_id = id_list[i]
      results_matrix[i, ] <- get_expected_rd_avatar(rd_data, orig_id, k, n_iter)
    }
    return(results_matrix)
  }

  if(n_cores==1) {
    return(process_obs(1:nrow(rd_data)))
  }
  else {
    cluster <- parallel::makeCluster(n_cores)
    on.exit(parallel::stopCluster(cluster))
    parallel::clusterExport(cluster, list("rd_data", "k", "n_iter", "get_rd_avatar"), envir=environment())
    id_lists <- split(1:nrow(rd_data), cut(1:nrow(rd_data), n_cores, labels = FALSE))
    expected_lists <- parallel::parLapply(cluster, id_lists, process_obs)
    expected_list <- do.call(rbind, expected_lists)
    return(expected_list)
  }
}



#' Avatarization of a dataset
#'
#' @description
#' `avatarize` returns a dataframe containing avatars of original observations, as described in  10.1038/s41746-023-00771-5.
#'
#' @details
#' Avatarization being a stochastic process, this function does not necessarily give the same result for successive calls with the same parameters.
#' The distance metric used in this implementation of the Avatar method is the Euclidean distance.
#'
#' @param data A dataframe containing original data.
#' @param k The number of nearest neighbors to consider.
#' @param npc The number of dimensions to use for dimensionality reduction.
#'
#' @return The avatar dataframe.
avatarize <- function(data, k, npc) {
  proj_res <- prcomp(data, center=TRUE, scale=TRUE)
  avat_rd_list <- list()
  for(obs_id in 1:nrow(data)) {
    avat_rd <- get_rd_avatar(proj_res$x[, 1:npc], obs_id, k)
    avat_rd_list[[obs_id]] <- avat_rd
  }
  avat_rd_matrix <- do.call(rbind, avat_rd_list)
  deproject_data <- function(mat, pca_result) {
    unrot <- mat %*% t(pca_result$rotation[, 1:ncol(pca_result$x[, 1:npc])])
    unrot <- sweep(unrot, 2, pca_result$scale, "*")
    unrot <- sweep(unrot, 2, pca_result$center, "+")
    return(unrot)
  }
  return(as.data.frame(deproject_data(avat_rd_matrix, proj_res)))
}
