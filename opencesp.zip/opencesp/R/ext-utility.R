#' Overlap of confidence intervals
#'
#' @description
#' `interval_overlap` returns the overlap of confidence intervals constructed from original and synthetic data,
#' as described (for example) in https://doi.org/10.1111/rssa.12358. Intervals are constructed from T distributions
#' in case of numerical data, and with the Pearson-Klopper method for binomial intervals in case of categorical data.
#'
#' @param orig A vector containing original data.
#' @param synth A vector containing synthetic data, of the same type as orig.
#' @param cat The category to consider to construct binomial intervals in case of categorical data.
#' @param conf.level The desired level of confidence for the confidence intervals.
#'
#' @return The computed overlap.
interval_overlap <- function(orig, synth, cat=NULL, conf.level=0.95) {
  if(is.numeric(orig) && is.numeric(synth)) {
    IC_orig <- t.test(orig, conf.level = conf.level)$conf.int
    IC_synth <- t.test(synth, conf.level = conf.level)$conf.int
  }
  else if(is.factor(orig) && is.factor(synth)) {
    if(is.null(cat)) cat <- names(table(orig))[1]
    IC_orig <- binom::binom.confint(x=sum(na.omit(orig) == cat), n=length(na.omit(orig)), method="exact")
    IC_orig <- c(IC_orig$lower, IC_orig$upper)
    IC_synth <- binom::binom.confint(x=sum(na.omit(synth) == cat), n=length(na.omit(synth)), method="exact")
    IC_synth <- c(IC_synth$lower, IC_synth$upper)
  }
  else {
    stop("Cannot construct intervals: vectors are not of the same type.")
  }
  l_o <- IC_orig[1] # Same notation as in https://doi.org/10.1111/rssa.12358.
  l_s <- IC_synth[1]
  u_o <- IC_orig[2]
  u_s <- IC_synth[2]
  IO <- 0.5*((min(u_o, u_s)-max(l_o, l_s))/(u_o-l_o)+(min(u_o, u_s)-max(l_o, l_s))/(u_s-l_s))
  return(IO)
}



#' Estimated Hellinger distance
#'
#' @description
#' `hellinger_distance` returns an estimate of the Hellinger distance between original and synthetic data,
#' as suggested (for example) in https://doi.org/10.1109/ACCESS.2022.3144765. The estimate is obtained using
#' package statip in case of continuous numerical data, and using the usual formula given in the reference article otherwise. TODO sans statip
#'
#' @param orig A vector containing original data.
#' @param synth A vector containing synthetic data, of the same type as orig.
#'
#' @return The estimated Hellinger distance.
hellinger_distance <- function(orig, synth) {
  if(is.numeric(orig) && is.numeric(synth) && !is.integer(orig) && !is.integer(synth)) {
    res <- tryCatch({ statip::hellinger(na.omit(orig), na.omit(synth)) }, error = function(e) { return(NA) })
    return(res)
  }
  else if(typeof(orig) == typeof(synth)) {
    orig <- as.factor(orig)
    synth <- as.factor(synth)
    categories <- union(levels(orig), levels(synth))
    sum <- 0
    for(cat in categories) {
      p_i <- sum(na.omit(orig) == cat)/length(na.omit(orig)) # Same notation as in https://doi.org/10.1109/ACCESS.2022.3144765.
      q_i <- sum(na.omit(synth) == cat)/length(na.omit(synth))
      sum <- sum + (sqrt(p_i)-sqrt(q_i))^2
    }
    return(sqrt(sum)/sqrt(2))
  }
  else {
    stop("Cannot calculate distance: vectors are not of the same type.")
  }
}

#' TODO 10.1093/jamia/ocaa249
mean_hellinger <- function(orig, synth) {
  return(mean(unlist(Map(hellinger_distance, orig, synth))))
}

#' Pairwise correlation difference
#'
#' @description
#' `get_PCD_num` returns the pairwise correlation difference, as defined in https://doi.org/10.1186/s12874-020-00977-1.
#' The metric is computed on subsets of the input dataframes represented by all their numerical variables.
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The pairwise correlation difference.
get_PCD_num <- function(orig, synth, convert = FALSE) {
  colnames(synth) <- colnames(orig)
  orig_num <- orig[, sapply(orig, is.numeric)]
  synth_num <- synth[, sapply(synth, is.numeric)]

  c_cols_orig <- which(apply(orig_num, 2, var) == 0)
  c_cols_synth <- which(apply(synth_num, 2, var) == 0)
  c_cols <- c(c_cols_orig, c_cols_synth)
  if(length(c_cols) > 0) {
    orig_num <- orig_num[, -c_cols]
    synth_num <- synth_num[, -c_cols]
  }

  mat_orig <- cor(orig_num, method="pearson", use="pairwise.complete.obs")
  mat_synth <- cor(synth_num, method="pearson", use="pairwise.complete.obs")
  return(norm(mat_orig - mat_synth, type="F"))
}



#' Cramer's V matrix
#'
#' @description
#' `cramers_mat` returns the matrix of Cramer's V computed between each pair of variables
#' in a dataframe.
#'
#' @param df A dataframe.
#'
#' @return The Cramer's V matrix.
cramers_mat <- function(df) {
  df <- df[, sapply(df, is.factor)]
  mat <- matrix(NA, ncol = ncol(df), nrow = ncol(df), dimnames = list(names(df), names(df)))
  for (i in 1:ncol(df)) {
    for (j in 1:ncol(df)) {
      mat[i, j] <- rcompanion::cramerV(df[[i]], df[[j]])
    }
  }
  return(mat)
}



#' Pairwise correlation difference adapted for categorical data
#'
#' @description
#' `get_PCD_cat` returns a metric adapted from the pairwise correlation difference suggested in
#' https://doi.org/10.1186/s12874-020-00977-1. Contrary to the original proposal, the matrices
#' from which the Frobenius norm is returned contain Cramer's V rather than Pearson
#' correlation coefficients. Consequently, the metric is suitable to nominal data, and is computed
#' on subsets of the input dataframes represented by all their categorical variables.
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The adapted pairwise correlation difference.
get_PCD_cat <- function(orig, synth) { #TODO : cf. get_PCD_num
  mat_orig <- cramers_mat(orig)
  mat_synth <- cramers_mat(synth)
  return(norm(mat_orig-mat_synth, type="F"))
}



#' TODO
pMSE <- function(orig, synth, method = "cart", ...) {
  colnames(orig)[colnames(orig) == "syn"] <- "syn_0"
  colnames(synth)[colnames(synth) == "syn"] <- "syn_0"
  orig$syn <- 0
  synth$syn <- 1
  bound <- rbind(orig, synth)
  if(method == "cart") {
    fit <- rpart::rpart(syn ~ ., data = bound, method = "class", ...)
    score <- predict(fit, bound, type = "prob")[, 2]
  }
  else if(method == "gbm") {
    fit <- gbm::gbm(syn ~ ., data = bound, ...) #TODO
    score <- predict(fit, bound, type = "response")
  }
  else { #TODO
    fit <- glm(syn ~ .^2, data = bound, family = binomial) # TODO .^n
    score <- predict(fit, bound, type = "response")
  }
  return(mean((score - nrow(synth) / nrow(bound))^2, na.rm = TRUE))
}



#' TODO caret
get_pMSE_cp <- function(orig, synth_l, xval = 25) {
  colnames(orig)[colnames(orig) == "syn"] <- "syn_0"
  orig$syn <- 0

  cp_vec <- sapply(synth_l, function(synth) {
    colnames(synth)[colnames(synth) == "syn"] <- "syn_0"
    synth$syn <- 1
    bound <- rbind(orig, synth)
    fit <- rpart::rpart(syn ~ ., data = bound, method = "class", minbucket = 1, cp = 0, xval = xval)
    fit$cptable[which.min(fit$cptable[,"xerror"]),"CP"] #' TODO fitcp
  })

  return(mean(cp_vec))
}


#' Cross-classification/regression metric
#'
#' @description
#' `get_CCRM` is an internal function intended to facilitate the calculation of cross-classification metrics,
#' as described in https://doi.org/10.1186/s12874-020-00977-1, and analogous regression metrics. For these calculations,
#' df1 is split into two parts of equal length, one for the training of CARTs and one to validate the predictions.
#'
#' @param df1 A dataframe.
#' @param df2 A dataframe with the same variables as df1.
#' @param mode Either "class" or "reg".
#' @param invert A boolean.
#'
#' @return The obtained metric.
get_CCRM <- function(df1, df2, mode="class", invert=FALSE) {
  sep_point <- nrow(df1) %/% 2
  df1_train <- df1[1:sep_point, ]
  df1_test <- df1[(sep_point + 1):nrow(df1), ]
  res <- c()
  names_iter <- if(mode=="class") names(df1)[sapply(df1, is.factor)] else names(df1)[sapply(df1, is.numeric)]
  for(var in names_iter) {
    rpart_method <- if(mode=="class") "class" else "anova"
    tree <- rpart::rpart(as.formula(paste(var, "~ .")), data=df1_train, method=rpart_method)
    predict_df1 <- predict(tree, df1_test, type="vector")
    predict_df2 <- predict(tree, df2, type="vector")
    if(mode=="class") {
        perf_df1 <- mean(predict_df1 == df1_test[[var]])
        perf_df2 <- mean(predict_df2 == df2[[var]])
    }
    else {
        perf_df1 <- mean(predict_df1 - df1_test[[var]])
        perf_df2 <- mean(predict_df2 - df2[[var]])
    }
    if(!invert) {
      res <- append(perf_df1/perf_df2, res)
    }
    else {
        res <- append(perf_df2/perf_df1, res)
    }
  }
  return(mean(res))
}



#' Cross-classification metric in the real-synthetic order
#'
#' @description
#' `get_CCM_RS` returns the CrCl-RS metric, as described in https://doi.org/10.1186/s12874-020-00977-1.
#' This metric is calculated by averaging the proportion of correct classifications for each categorical
#' variable of input dataframes. Used classifiers are CART. Training and hold-out sets respectively correspond
#' to the first and second half of the original data.
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The CrCl-RS metric.
get_CCM_RS <- function(orig, synth) {
    return(get_CCRM(orig, synth))
}



#' Cross-classification metric in the synthetic-real order
#'
#' @description
#' `get_CCM_SR` returns the CrCl-SR metric, as described in https://doi.org/10.1186/s12874-020-00977-1.
#' (see \code{\link{get_CCM_RS}}).
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The CrCl-SR metric.
get_CCM_SR <- function(orig, synth) {
    return(get_CCRM(synth, orig, invert=TRUE))
}



#' Cross-regression metric in the real-synthetic order
#'
#' @description
#' `get_CRM_RS` returns a cross-regression metric, adapted from the CrCl-RS metric described
#' in https://doi.org/10.1186/s12874-020-00977-1. This metric is calculated by averaging the
#' accuracy of regressions performed for each numerical variable of input dataframes. Regression are
#' performed using CART. Training and hold-out sets respectively correspond to the first and second
#' half of the original data.
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The cross-regression metric.
get_CRM_RS <- function(orig, synth) {
    return(get_CCRM(orig, synth, mode="reg"))
}



#' Cross-regression metric in the synthetic-real order
#'
#' @description
#' `get_CRM_SR` returns a cross-regression metric, adapted from the CrCl-SR metric described
#' in https://doi.org/10.1186/s12874-020-00977-1 (see \code{\link{get_CRM_RS}}).
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The cross-regression metric.
get_CRM_SR <- function(orig, synth) {
    return(get_CCRM(orig, synth, mode="reg", invert=TRUE))
}



#' Log-cluster metric
#'
#' @description
#' `get_LCM` returns a log-cluster metric, as described in https://doi.org/10.1186/s12874-020-00977-1.
#' This metric is based on cluster analysis as proposed initially in https://doi.org/10.29012/jpc.v1i1.568.
#' Here we perform cluster analysis based on Gower's distance to account for mixed data types (see for example
#' https://doi.org/10.48550/arXiv.2101.02481).
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#' @param n_clusters The number of clusters to use.
#'
#' @return The log-cluster metric.
get_LCM <- function(orig, synth, n_clusters) {
    df <- rbind(orig, synth)
    d_dist <- cluster::daisy(df, metric = "gower")
    hc <- hclust(d_dist, method = "complete")
    clusters <- cutree(hc, k=n_clusters)
    df <- cbind(df, cluster=as.factor(clusters))
    orig_cl <- head(df, nrow(orig))
    synth_cl <- tail(df, nrow(synth))
    c_sum <- 0
    N_O <- nrow(orig) # Same notation as in https://doi.org/10.29012/jpc.v1i1.568.
    N_M <- nrow(synth)
    c <- N_O / (N_O + N_M)
    for(i in 1:n_clusters) {
        n_jo <- sum(orig_cl$cluster == i)
        n_j <- sum(df$cluster == i)
        if(n_j > 0) c_sum <- c_sum + (n_jo/n_j - c)^2 # TODO
    }
    return(log(c_sum/n_clusters))
}



#' Empirical Cumulative Distribution Function
#'
#' @description
#' `get_ECDF` returns the empirical CDF obtained from a numerical dataframe.
#'
#' @param df A dataframe containing only numerical columns, with no missing values.
#'
#' @return The CDF, taking numerical vectors of the same length as df's rows as parameters.
get_ECDF <- function(df) {
  func <- function(vec) {
    i_sum <- 0
    for(i in 1:nrow(df)) {
      obs <- df[i, ]
      cond <- TRUE
      for(j in 1:ncol(df)) {
        if(obs[j] > vec[j]) {
          cond <- FALSE
          break
        }
      }
      if(cond) {
        i_sum <- i_sum + 1
      }
    }
    return(i_sum/nrow(df))
  }
  return(func)
}



#' Replace factor variables by binary indicator variables
#'
#' @description
#' `replace_factor_var` replace the factor variables in a dataframe by a series of binary indicator variables,
#' namely one indicator variable for each modality of the original factor variable.
#'
#' @param df A dataframe.
#'
#' @return The dataframe with factor variables replaced.
#' #' TODO remplacer par fastDummies::dummy_cols(ad, remove_first_dummy = TRUE, remove_selected_columns = TRUE)
replace_factor_var <- function(df) {
  cbind.fill <- function(...){
    nm <- list(...)
    nm <- lapply(nm, as.matrix)
    n <- max(sapply(nm, nrow))
    do.call(cbind, lapply(nm, function (x) rbind(x, matrix(, n-nrow(x), ncol(x)))))
  }

  factor_columns <- sapply(df, is.factor)
  df_dummies <- data.frame()
  for (col_name in names(df)[factor_columns]) {
    dummies <- model.matrix(~ . - 1, data = df[col_name])
    colnames(dummies) <- paste(col_name, colnames(dummies), sep = "_")
    df_dummies <- cbind.fill(df_dummies, dummies)
  }
  df <- df[, !factor_columns]
  df <- cbind(df, df_dummies)
  return(df)
}



#' Average squared differences between empirical distributions
#'
#' @description
#' `get_ASDED` returns an empirical distributions-based metric, as proposed in https://doi.org/10.29012/jpc.v1i1.568
#' (see equation 5 in this paper). Potential missing values in the input dataframes are imputed using random forests
#' before proceeding with the metric's calculation.
#'
#' @param orig A dataframe containing original data.
#' @param synth A dataframe containing synthetic data, with the same variables as orig.
#'
#' @return The ASDED metric.
get_ASDED <- function(orig, synth) {
  if(sum(orig[, sapply(orig, is.numeric)]) < ncol(orig)) {
    orig_num <- replace_factor_var(missForest::missForest(orig)$ximp) # TODO : utils
    synth_num <- replace_factor_var(missForest::missForest(synth)$ximp)
  }
  else {
    orig_num <- orig
    synth_num <- synth
  }
  ecdf_orig <- get_ECDF(orig_num)
  ecdf_synth <- get_ECDF(synth_num)
  merged <- rbind(orig_num, synth_num)
  sum <-0
  for(i in 1:nrow(merged)) {
      sum <- sum + (ecdf_orig(merged[i,])-ecdf_synth(merged[i,]))^2
  }
  return(sum/nrow(merged))
}
