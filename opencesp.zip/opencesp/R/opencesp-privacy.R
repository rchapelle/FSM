#' Values bounding an observed one in a population, estimated using a given distribution
#'
#' @description
#' `get_bounding_vals` follows a Monte Carlo approach to estimate the prior and subsequent values (in the ascending order)
#' of a numerical variable in a source population, relative to an observed value.
#'
#' @param x The observed value.
#' @param n_trials The number of trials for the Monte Carlo simulation.
#' @param pop_size The size of the source population.
#' @param rand_func The function to use to approximate the distribution of the variable in the source population
#' (must return a random vector and take its size as a first parameter).
#' @param n_cores The number of logical processes to use for the computation. If set to NULL, the function will
#' attempt to determine the number of physical cores on the device and use this number, minus one.
#' @param ... Additional parameters of the distribution function.
#'
#' @return A list of values.
#'  \itemize{
#'    \item lower - The estimated lower bounding value.
#'    \item upper - The estimated upper bounding value.
#'  }
get_bounding_vals <- function(x, n_trials, pop_size, rand_func, n_cores=NULL, ...) {
  if(is.null(n_cores)) n_cores <- parallel::detectCores() - 1
  ellipsis_args <- list(...)

  estimate <- function(number) {
    lower_sims <- numeric(number)
    upper_sims <- numeric(number)
    for (i in 1:number) {
      repeat {
        sample <- do.call(rand_func, c(list(pop_size-1), ellipsis_args))
        above_x <- sample[sample > x]
        below_x <- sample[sample < x]
        if (length(above_x) != 0 && length(below_x) != 0) {
          lower_sims[i] <- max(below_x, na.rm = TRUE)
          upper_sims[i] <- min(above_x, na.rm = TRUE)
          break
        }
      }
    }
    return(list(lower = lower_sims, upper = upper_sims))
  }

  cluster <- parallel::makeCluster(n_cores)
  parallel::clusterExport(cluster, list("x", "pop_size", "rand_func", "ellipsis_args"), envir=environment())
  lists <- parallel::parLapply(cluster, get_chunks(n_trials, n_cores), estimate)
  parallel::stopCluster(cluster)

  lower_list <- unlist(lapply(lists, function(lst) lst$lower))
  upper_list <- unlist(lapply(lists, function(lst) lst$upper))


  lower_val <- mean(lower_list, na.rm = TRUE)
  upper_val <- mean(upper_list, na.rm = TRUE)
  return(list(lower = lower_val, upper = upper_val))
}



#' Random value generated from a particular mixture distribution
#'
#' @description
#' `get_S_value` generates a random value from a mixture distribution, such that a fixed value is returned approximately
#' 1/N times and a value generated from a specified distribution is returned approximately (N-1)/N times.
#'
#' @details
#' The distribution from which values are generated is described in https://arxiv.org/ftp/arxiv/papers/2310/2310.06571.pdf, where
#' variables following this distribution are denoted "S_k".
#'
#' @param x_a The value to return approximately 1/N times.
#' @param lower_val The estimated lower bounding value of x_a.
#' @param upper_val The estimated upper bounding value of x_a.
#' @param pop_size The size of the source population.
#' @param rand_func The function to use to approximate the underlying distribution
#' (must return a random vector and take its size as a first parameter).
#' @param ... Additional parameters of the distribution function.
#'
#' @return A numerical random value.
get_S_value <- function(x_a, lower_val, upper_val, pop_size, rand_func, ...) {
  first_draw=sample(1:pop_size, 1)
  if(first_draw==1) {
    return(x_a)
  }
  else {
    repeat{
      second_draw <- rand_func(1, ...)
      if(second_draw < lower_val || second_draw > upper_val) {
        return(second_draw)
      }
    }
  }
}



#' Random sample generated from a particular mixture distribution
#'
#' @description
#' `get_S_sample` generates a random sample from a mixture distribution, such that a fixed value is returned approximately
#' 1/N times and a value generated from a specified distribution is returned approximately (N-1)/N times.
#'
#' @details
#' The distribution from which values are generated is described in https://arxiv.org/ftp/arxiv/papers/2310/2310.06571.pdf, where
#' variables following this distribution are denoted "S_k".
#'
#' @param x_a The value to return approximately 1/N times.
#' @param lower_val The estimated lower bounding value of x_a.
#' @param upper_val The estimated upper bounding value of x_a.
#' @param pop_size The size of the source population.
#' @param sample_size The desired sample size.
#' @param rand_func The function to use to approximate the underlying distribution
#' (must return a random vector and take its size as a first parameter).
#' @param n_cores The number of logical processes to use for the computation. If set to NULL, the function will
#' attempt to determine the number of physical cores on the device and use this number, minus one.
#' @param ... Additional parameters of the distribution function.
#'
#' @return A numerical random vector.
get_S_sample <- function(x_a, lower_val, upper_val, pop_size, sample_size, rand_func, n_cores, ...) {
  if(is.null(n_cores)) n_cores <- parallel::detectCores() - 1
  ellipsis_args <- list(...)

  generate <- function(number) {
    res <- numeric(number)
    for(i in 1:number) {
      res[i] <- do.call(get_S_value, c(list(x_a, lower_val, upper_val, pop_size, rand_func), ellipsis_args))
    }
    return(res)
  }
  cluster <- parallel::makeCluster(n_cores)
  parallel::clusterExport(cluster, list("x_a", "lower_val", "upper_val", "pop_size", "rand_func", "ellipsis_args"), envir=environment())
  lists <- parallel::parLapply(cluster, get_chunks(sample_size, n_cores), generate)
  parallel::stopCluster(cluster)

  all_res <- unlist(lists)

  return(all_res)
}



#' Elemental Correct Attribution Probability (ECAP)
#'
#' @description
#' `get_ECAP` computes the ECAP from given parameters, as described in https://arxiv.org/ftp/arxiv/papers/2310/2310.06571.pdf.
#'
#' @details
#' This is the implementation corresponding to a normal noise addition. Non-normal noise are not supported for the time being.
#'
#' @param x_a The target value to protect.
#' @param lower_val The estimated lower bounding value of x_a.
#' @param upper_val The estimated upper bounding value of x_a.
#' @param src_size The size of the source population.
#' @param sd_noise The desired standard deviation of the normal noise to add.
#' @param st_size The size of the studied population.
#' @param n_trials The desired number of trials for Monte Carlo steps of the algorithm.
#' @param rand_func The function to use to model the distribution of the variable in the source population.
#' (must return a random vector and take its size as a first parameter).
#' @param ... Additional parameters of the distribution function.
#'
#' @return The desired ECAP, as a numerical value.
get_ECAP <- function(x_a, lower_val, upper_val, src_size, sd_noise, st_size, n_trials, rand_func, ...) {
  I <- c((x_a+lower_val)/2,(x_a+upper_val)/2)
  S1 <- get_S_sample(x_a, lower_val, upper_val, src_size, n_trials, rand_func, n_cores=NULL, ...)
  B1 <- stats::rnorm(n_trials, mean=0, sd=sd_noise)
  P1 <- 1 - sum((S1 + B1 >= I[1]) & (S1 + B1 <= I[2])) / n_trials
  P2 <- stats::pnorm((upper_val-x_a)/2, mean = 0, sd = sd_noise) - stats::pnorm((lower_val-x_a)/2, mean = 0, sd = sd_noise)
  return(1-(((src_size-1)/src_size)^st_size-(P1+(P2-1)/src_size)^st_size)/(1-P1^st_size))
}



#' Univariate correct attribution probability
#'
#' @description
#' `get_univ_att_prob` computes the univariate correct attribution probability from given parameters, as described in https://arxiv.org/ftp/arxiv/papers/2310/2310.06571.pdf.
#'
#' @details
#' When the input dataframe contains only categorical variables, the value returned is the proportion of rows in the dataframe having the same combination of values
#' as the input row. When the input dataframe also contains numerical variables, this value is weighted according to the proximity between these variables in the
#' input row vs. each other row of the dataframe. The weights are defined by radii passed as parameters.
#'
#' @param row The target row of the dataframe.
#' @param data A dataframe.
#' @param rad A vector containing radii, one for each numerical variable of the dataframe. The order of radii must be the order of numerical variables in the dataframe.
#'
#' @return The computed probability.
get_univ_att_prob <- function(row, data, rad) {
  cat_vars <- sapply(row, function(col) !is.numeric(col))
  cat_vars <- names(row)[cat_vars]
  num_vars <- setdiff(names(row), cat_vars)
  correctness <- numeric(0)
  for(i in 1:nrow(data)) {
    row_2 <- data[i,, drop = FALSE]
    if(any(!mapply(identical, row[cat_vars], row_2[cat_vars]))) {
      correctness[i] <- 0
    }
    else {
      if(length(num_vars) == 0) {
        correctness[i] <- 1
      }
      else {
        num_row_1 <- row[num_vars]
        num_row_2 <- row_2[num_vars]

        na_1 <- is.na(num_row_1)
        na_2 <- is.na(num_row_2)
        num_row_1[na_1 & !na_2] <- num_row_2[na_1 & !na_2]
        num_row_2[!na_1 & na_2] <- num_row_1[!na_1 & na_2]
        num_row_1[na_1 & na_2] <- 0
        num_row_2[na_1 & na_2] <- 0

        result <- sum(pmax(0, -abs(num_row_1 - num_row_2)/rad + 1)/length(num_row_1))
        correctness[i] <- result
      }
    }
  }
  return(mean(correctness))
}



#' Proximity coefficient between rows of a dataframe
#'
#' @description
#' `get_prox_coef` returns a proximity coefficient between two rows of a given dataframe, according to specified radii.
#'
#' @details
#' When the input dataframe contains only categorical variables, this returns either 0 or 1 depending on the value of these variables in the rows.
#' When the input dataframe also contains numerical variables, this value is weighted according to the proximity between these variables in the
#' input rows. The weights are defined by radii passed as parameters.
#'
#' @param row_1 A row of a dataframe.
#' @param row_2 Another row of the same dataframe.
#' @param rad A vector containing radii, one for each numerical variable of the dataframe. The order of radii must be the order of numerical variables in the dataframe.
#'
#' @return The computed probability.
get_prox_coef <- function(row_1, row_2, rad) {
  cat_vars <- sapply(row_1, function(col) !is.numeric(col))
  cat_vars <- names(row_1)[cat_vars]
  if(any(!mapply(identical, row_1[cat_vars], row_2[cat_vars]))) {
    return(0)
  }
  num_vars <- setdiff(names(row_1), cat_vars)
  if(length(num_vars) == 0) {
    return(1)
  }
  num_row_1 <- row_1[num_vars]
  num_row_2 <- row_2[num_vars]

  na_1 <- is.na(num_row_1)
  na_2 <- is.na(num_row_2)
  num_row_1[na_1 & !na_2] <- num_row_2[na_1 & !na_2]
  num_row_2[!na_1 & na_2] <- num_row_1[!na_1 & na_2]
  num_row_1[na_1 & na_2] <- 0
  num_row_2[na_1 & na_2] <- 0

  result <- sum(pmax(0, -abs(num_row_1 - num_row_2)/rad + 1)/length(num_row_1))
  return(result)
}



#' Generalized Correct Attribution Probability (GCAP)
#'
#' @description
#' `get_GCAP` returns the GCAP for a given row of a dataframe, as described in https://arxiv.org/ftp/arxiv/papers/2310/2310.06571.pdf.
#'
#' @param row A row of a dataframe.
#' @param data The dataframe.
#' @param keys A vector containing names of variables of the dataframe to take as keys.
#' @param rad_keys A vector containing radii, one for each numerical key. The order of radii must correspond to the order of variables in the dataframe.
#' @param targets A vector containing names of variables of the dataframe to take as targets.
#' @param rad_targets A vector containing radii, one for each numerical target. The order of radii must correspond to the order of variables in the dataframe.
#'
#' @return The computed probability.
get_GCAP <- function(row, data, keys, rad_keys, targets, rad_targets) {
  cat_vars <- sapply(data, function(col) !is.numeric(col))
  cat_vars <- names(data)[cat_vars]
  cat_keys <- subset(keys, keys %in% cat_vars)

  n_corr <- sum(sapply(cat_keys, function(key) {
    return(data[[key]] == row[[key]])
  }), na.rm = TRUE)

  if(n_corr == 0) {
    return(0)
  }

  key_row <- row[keys]
  key_data <- data[,keys]
  coefs_keys <- sapply(1:nrow(key_data), function(i) {
    get_prox_coef(key_data[i, , drop = FALSE], key_row, unlist(rad_keys))
  })
  if(sum(coefs_keys) == 0) {
    return(0)
  }
  target_row <- row[targets]
  target_data <- data[,targets, drop = FALSE]

  coefs_targets <- sapply(1:nrow(target_data), function(i) {
    get_prox_coef(target_data[i, , drop = FALSE], target_row, unlist(rad_targets))
  })

  return (sum(coefs_keys*coefs_targets)/sum(coefs_keys))
}



#' Statistically unique rows of a dataframe
#'
#' @description
#' `get_unique_rows` returns the unique rows of dataframe, according to specified keys and radii.
#'
#' @param data The dataframe.
#' @param keys A vector containing names of variables of the dataframe to take as keys.
#' @param rad_keys A vector containing radii, one for each numerical key. The order of radii must correspond to the order of variables in the dataframe.
#'
#' @return A dataframe composed of unique rows only.
get_unique_rows <- function(data, keys, rad_keys) {
  cat_vars <- sapply(data, function(col) !is.numeric(col))
  cat_vars <- names(data)[cat_vars]
  cat_keys <- subset(keys, keys %in% cat_vars)
  num_vars <- setdiff(names(data), cat_vars)
  num_keys <- subset(keys, keys %in% num_vars)

  unique_rows_cat <- data[!duplicated(data[, cat_keys]) & !duplicated(data[, cat_keys], fromLast = TRUE), ]
  dup_rows_cat <- data[!(duplicated(data[, cat_keys]) | duplicated(data[, cat_keys], fromLast = TRUE)), ]

  unique_rows_all <- data[FALSE, ]

  if(length(num_keys)>0) {
    for(i in 1:nrow(dup_rows_cat)) {
      current_row <- dplyr::slice(dup_rows_cat, i)
      is_unique <- TRUE
      for(j in 1:nrow(dup_rows_cat)) {
        if(i==j) {
          next
        }
        comp_row <- dplyr::slice(dup_rows_cat, j)
        for(id_key in 1:length(num_keys)) {
          key <- num_keys[id_key]
          radius <- rad_keys[id_key]
          if(!is.na(current_row[[key]]) && !is.na(comp_row[[key]]) && abs(current_row[[key]]-comp_row[[key]]) < radius) {
            is_unique <- FALSE
            break
          }
        }
        if(!is_unique) {
          break
        }
      }

      if(is_unique) {
        unique_rows_all <- dplyr::bind_rows(unique_rows_all, current_row)
      }
    }
  }
  unique_rows_all <- dplyr::bind_rows(unique_rows_all, unique_rows_cat)
  return(unique_rows_all)
}



#' Generalized Targeted Correct Attribution Probability (GTCAP)
#'
#' @description
#' `get_GTCAP` computes the GTCAP for a synthetic version of a dataframe, as described in https://arxiv.org/ftp/arxiv/papers/2310/2310.06571.pdf.
#'
#' @param orig The original dataframe.
#' @param synth The synthetic dataframe.
#' @param keys A vector containing names of variables of the dataframe to take as keys.
#' @param rad_keys A vector containing radii, one for each numerical key. The order of radii must correspond to the order of variables in the dataframe.
#' @param targets A vector containing names of variables of the dataframe to take as targets.
#' @param rad_targets A vector containing radii, one for each numerical target. The order of radii must correspond to the order of variables in the dataframe.
#' @param n_cores The number of logical processes to use for the computation. If set to NULL, the function will
#' attempt to determine the number of physical cores on the device and use this number, minus one.
#'
#' @return A list of values.
#'  \itemize{
#'    \item mean - The standardized mean GCAP for target synthetic rows.
#'    \item ind - A vector containing standardized GCAP values, one for each target synthetic row.
#'  }
get_GTCAP <- function(orig, synth, keys, rad_keys, targets, rad_targets, n_cores=NULL) {
  if(is.null(n_cores)) n_cores <- parallel::detectCores() - 1

  unique_rows <- get_unique_rows(orig, c(keys, targets), c(rad_keys, rad_targets)) #on considère les uniques à la fois selon les clés et les cibles

  process_rows <- function(id_list) {
    ind_baseline <- numeric(nrow(unique_rows))
    ind_CAP_orig <- numeric(nrow(unique_rows))
    ind_CAP_synth <- numeric(nrow(unique_rows))
    ind_GCAP <- numeric(nrow(unique_rows))

    for(i in id_list) {
      row <- unique_rows[i, , drop = FALSE]

      ind_baseline[i] <- get_univ_att_prob(row[, targets, drop = FALSE], orig[, targets, drop = FALSE], rad_targets)
      ind_CAP_synth[i] <- get_GCAP(row, synth, keys, unlist(rad_keys), targets, unlist(rad_targets))
      ind_CAP_orig[i] <- get_GCAP(row, orig, keys, unlist(rad_keys), targets, unlist(rad_targets))
      ind_GCAP[i] <- NaN

      if(ind_CAP_orig[i]-ind_baseline[i] != 0) {
        if(ind_baseline[i] > ind_CAP_synth[i]) {
          ind_GCAP[i] <- 0
        }
        else if(ind_baseline[i] > ind_CAP_orig[i]) {
          ind_GCAP[i] <- 0
        }
        else if(ind_CAP_synth[i] > ind_CAP_orig[i]) {
          ind_GCAP[i] <- 1
        }
        else {
          ind_GCAP[i] <- (ind_CAP_synth[i] - ind_baseline[i]) / (ind_CAP_orig[i] - ind_baseline[i])
        }
      }
    }
    return(list(baseline = ind_baseline, CAP_orig = ind_CAP_orig, CAP_synth = ind_CAP_synth, GCAP = ind_GCAP))
  }

  cluster <- parallel::makeCluster(n_cores)
  parallel::clusterExport(cluster, list("orig", "synth", "keys", "rad_keys", "targets", "rad_targets", "unique_rows"), envir=environment())
  split_id <- split(1:nrow(unique_rows), cut(1:nrow(unique_rows), n_cores, labels = FALSE))
  lists <- parallel::parLapply(cluster, split_id, process_rows)
  parallel::stopCluster(cluster)

  ind_baseline <- unlist(lapply(lists, function(lst) lst$baseline))
  ind_CAP_orig <- unlist(lapply(lists, function(lst) lst$CAP_orig))
  ind_CAP_synth <- unlist(lapply(lists, function(lst) lst$CAP_synth))
  ind_GCAP <- unlist(lapply(lists, function(lst) lst$GCAP))

  mean_baseline <- mean(ind_baseline, na.rm=TRUE)
  mean_orig <- mean(ind_CAP_orig, na.rm=TRUE)
  mean_synth <- mean(ind_CAP_synth, na.rm=TRUE)

  res <- list(mean=(mean_synth-mean_baseline)/(mean_orig-mean_baseline), ind=ind_GCAP)
  return(res)
}


#' TODO https://docs.sdv.dev/sdmetrics/metrics/metrics-in-beta/outliercoverage
outlier_coverage <- function(orig, synth) {
  num_cols <- sapply(orig, is.numeric)
  orig <- orig[, num_cols]
  synth <- synth[, num_cols]

  calc_score <- function(orig_vec, synth_vec) {
    Q1 <- quantile(orig_vec, 0.25, na.rm = TRUE)
    Q3 <- quantile(orig_vec, 0.75, na.rm = TRUE)

    lb <- Q1 - 1.5 * (Q3 - Q1)
    rb <- Q3 + 1.5 * (Q3 - Q1)

    real_out <- sum(orig_vec < lb | orig_vec > rb, na.rm = TRUE)
    synth_out <- sum(synth_vec < lb | synth_vec > rb, na.rm = TRUE)

    p_real <- real_out / sum(!is.na(orig_vec))
    p_synth <- synth_out / sum(!is.na(synth_vec))

    return(min(p_synth / p_real, 1))
  }

  scores <- mapply(calc_score, orig, synth, SIMPLIFY = TRUE)
  return(mean(scores, na.rm = TRUE))
}
