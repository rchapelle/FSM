#' Overestimate of the Mahalanobis distance between two rows with NA
#'
#' @description
#' `get_overest_dist` returns an overestimate of the Mahalanobis distance between two rows containing NA values.
#'
#' @details
#' The distance returned is computed on alternate versions of these rows where NA have been replaced by other
#' existing values in the dataset. These values are chosen to maximize the distance. When the original rows
#' contain no missing value, this function simply returns the Mahalanobis distance computed on them.
#'
#' @param data A dataframe containing only numeric columns.
#' @param row_1 A row of the dataframe.
#' @param row_2 A row of the dataframe.
#' @param S The covariance matrix of the distribution.
#' @return A distance.
get_overest_dist <- function(data, row_1, row_2, S) {
  row_1_mod <- row_1
  row_2_mod <- row_2
  for (col_id in 1:length(row_1)) {
    val_1 <- row_1[col_id]
    val_2 <- row_2[col_id]
    min_val <- min(data[, col_id], na.rm = TRUE)
    max_val <- max(data[, col_id], na.rm = TRUE)
    if (!is.na(val_1) & !is.na(val_2)) {
      next
    }
    else if (!is.na(val_1) & is.na(val_2)) {
      farthest_val <- max(abs(data[, col_id] - val_1), na.rm = TRUE)
      row_2_mod[col_id] <- farthest_val
    }
    else if (is.na(val_1) & !is.na(val_2)) {
      farthest_val <- max(abs(data[, col_id] - val_2), na.rm = TRUE)
      row_1_mod[col_id] <- farthest_val
    }
    else {
      row_1_mod[col_id] <- min_val
      row_2_mod[col_id] <- max_val
    }
  }
  return(stats::mahalanobis(row_1_mod, row_2_mod, S))
}



#' Underestimate of the Mahalanobis distance between two rows with NA
#'
#' @description
#' `get_underest_dist` returns an underestimate of the Mahalanobis distance between two rows containing NA values.
#'
#' @details
#' The distance returned is computed on alternate versions of these rows where NA have been replaced by other
#' existing values in the dataset. These values are chosen to minimize the distance. When the original rows
#' contain no missing value, this function simply returns the Mahalanobis distance computed on them.
#'
#' @param row_1 A row of a dataframe containing only numeric columns.
#' @param row_2 A row of the same dataframe.
#' @param S The covariance matrix of the distribution.
#' @return A distance.
get_underest_dist <- function(row_1, row_2, S) {
  row_1_mod <- row_1
  row_2_mod <- row_2
  for(col_id in 1:length(row_1)) {
    val_1 <- row_1[col_id]
    val_2 <- row_2[col_id]
    if (!is.na(val_1) & !is.na(val_2)) {
      next
    }
    else if (!is.na(val_1) & is.na(val_2)) {
      row_2_mod[col_id] <- val_1
    }
    else if (is.na(val_1) & !is.na(val_2)) {
      row_1_mod[col_id] <- val_2
    }
    else {
      row_1_mod[col_id] <- 0
      row_2_mod[col_id] <- 0
    }
  }
  return(stats::mahalanobis(row_1_mod, row_2_mod, S))
}



#' Minimum overestimated Mahalanobis distance between each row of a dataframe and the other ones
#'
#' @description
#' `get_min_dist_tab` returns a vector of which first element represents the overestimated Mahalanobis
#' distance between the first row of the dataframe and the row closest to it, etc.
#'
#' @details
#' Overestimated distances are computed using `get_overest_dist`.
#'
#' @param data A dataframe containing only numeric columns, or factor columns with numeric values (these will be converted to numeric).
#' @return A vector of distances.
get_min_dist_tab <- function(data) {
  data <- data.frame(lapply(data, function(x) if(is.factor(x)) as.numeric(as.character(x)) else x))
  S <- stats::cov(data, use='complete.obs')
  min_dist_tab <- numeric(nrow(data))
  for(i in 1:nrow(data)) {
    row <- data[i, ]
    min_dist <- Inf
    for(j in 1:nrow(data)) {
      if(i==j) next
      row_2 <- data[j, ]
      min_dist <- min(min_dist, get_overest_dist(data, as.numeric(row), as.numeric(row_2), S))
    }
    min_dist_tab[i] <- min_dist
  }
  return(min_dist_tab)
}



#' Distance-based filtering of a synthetic dataframe
#'
#' @description
#' `filt_by_dist` implements the distance-based filtering described in https://arxiv.org/abs/2310.06571.
#'
#' @param data An original dataframe.
#' @param min_dist_tab A vector of minimal distances between rows of the original dataframe.
#' @param data_synth A synthetic version of the original dataframe.
#' @param features A vector of variable names to use in the filtering process.
#' @param n_cores The number of logical processes to use for the synthesis. If set to NULL, the function will
#' attempt to determine the number of physical cores on the device and use this number, minus one.
#' @return A filtered version of data_synth.
filt_by_dist <- function(data, min_dist_tab, data_synth, features, n_cores=NULL) {
  if(is.null(n_cores)) n_cores <- parallel::detectCores() - 1

  A <- data[, features]
  A <- data.frame(lapply(A, function(x) if(is.factor(x)) as.numeric(as.character(x)) else x))
  B <- data_synth[,features]
  B <- data.frame(lapply(B, function(x) if(is.factor(x)) as.numeric(as.character(x)) else x))
  S <- stats::cov(A,use='complete.obs')

  process_B_rows <- function(id_list_B) {
    supp_list <- c()
    for(j in id_list_B) {
      row_B <- as.numeric(B[j,])
      dist_AB <- c()
      dist_AA <- numeric(nrow(A))
      for(i in 1:nrow(A)) {
        row_A <- as.numeric(A[i,])
        dist_AB[i] <- get_underest_dist(row_A, row_B, S)
      }
      min_dist_AB <- min(dist_AB)
      i_min <- which.min(dist_AB)
      min_dist_AA <- min_dist_tab[i_min]
      if (min_dist_AB < min_dist_AA) {
        supp_list <- append(supp_list, j)
      }
    }
    return(supp_list)
  }

  cluster <- parallel::makeCluster(n_cores)
  parallel::clusterExport(cluster, list("A", "B", "S", "min_dist_tab", "get_underest_dist", "process_B_rows"), envir=environment())
  split_id_B <- split(1:nrow(B), cut(1:nrow(B), n_cores, labels = FALSE))
  supp_lists <- parallel::parLapply(cluster, split_id_B, process_B_rows)
  parallel::stopCluster(cluster)

  supp_list <- unique(unlist(supp_lists))

  data_filtered <- data_synth
  if(length(supp_list) > 0) {
    data_filtered <- data_synth[-supp_list, ]
  }
  return(data_filtered)
}



#' Synthesis and filtering of a dataframe
#'
#' @description
#' `get_filt_synth_data` generates a synthetic dataset from an original one, with each synthetic row respecting the
#' distance criterion described in https://arxiv.org/abs/2310.06571.
#'
#' @param orig An original dataframe.
#' @param synth_name A string representing the synthesizer to use (currently the only supported value is "CART").
#' @param size The number of rows to synthesize/filter.
#' @param features A vector of variable names to use in the filtering process.
#' @param seed The seed to use for pseudo-random numbers generation.
#' @param ... Additional parameters for the synthesizer.
#' @return A synthetic and filtered version of orig.
get_filt_synth_data <- function(orig, synth_name, size, features, seed, ...) {
  if(missing(size)) size <- nrow(orig)
  orig_feat_num <- orig[, features]
  #orig_feat_num <- orig_feat_num[, !sapply(orig_feat_num, is.factor)]
  min_dist_tab <- get_min_dist_tab(orig_feat_num)
  kept_data <- orig[0,]
  repeat {
    if(synth_name == "CART") {
      synth_data <- synthpop::syn(orig, k=size-nrow(kept_data), method="cart", seed=seed, ...)$syn
    }
    else {
      stop("Error: wrong synthesizer name")
    }
    filtered_data <- filt_by_dist(orig, min_dist_tab, synth_data, features)
    kept_data <- rbind(kept_data, filtered_data)
    if(nrow(kept_data)==size) {
      break
    }
    seed <- seed+1
  }
  return(kept_data)
}









#TODO


syn_gbm <- function(data, gen_mods = NULL, visit_sequence = (1:ncol(data)), m = 1, k = nrow(data), p = 0.1, ...) { #TODO MoM : cas de la première variable dans l'ordre de visite
  varnames <- dimnames(data)[[2]]
  nvar <- ncol(data)
  predictor_matrix <- matrix(0, nvar, nvar)
  predictor_matrix[visit_sequence, visit_sequence] <- outer(1:length(visit_sequence), 1:length(visit_sequence), ">")
  dimnames(predictor_matrix) <- list(varnames, varnames)
  diag(predictor_matrix) <- 0
  synth_l <- lapply(1:m, function(i) data[rep(NA, k), ])
  if(is.null(gen_mods)) gen_mods_c <- list()
  else gen_mods_c <- gen_mods
  for(i in 1:length(visit_sequence)) {
    var_id <- visit_sequence[i]
    y <- data[[var_id]]
    if(i == 1) { # First variable is synthesized by sampling from the original vector
      for(j in 1:m) {
        synth_l[[j]][[var_id]] <- sample(y, size = k, replace = TRUE)
      }
    }
    else { # Other are synthesized using the predictor matrix
      hasNA <- any(is.na(y))

      if(is.null(gen_mods)) {
        x <- data[, which(predictor_matrix[var_id, ] == 1), drop = FALSE]
        if(is.factor(y)) y <- addNA(y, ifany = TRUE)
        y_val <- y
        x_val <- x
        mod_NA <- NULL
        if(!is.factor(y) && hasNA) {
          y_NA <- is.na(y)
          mod_NA <- gbm_custom(y_NA ~ ., data = as.data.frame(cbind(y_NA, x_val)), ...)
          y_val <- y[y_NA == FALSE]
          x_val <- x[y_NA == FALSE, ]
        }
        mod_val <- gbm_custom(y_val ~ ., data = as.data.frame(cbind(y_val, x_val)), ...)
        gen_mods_c[[i-1]] <- list(mod_val = mod_val, mod_NA = mod_NA)
      }
      else {
        mod_val <- gen_mods[[i-1]]$mod_val
        mod_NA <- gen_mods[[i-1]]$mod_NA
      }

      for(j in 1:m) {
        x_synth <- synth_l[[j]][, which(predictor_matrix[var_id, ] == 1), drop = FALSE]
        if(is.factor(y) && hasNA) {
          predicted <- predict.gbm_custom(mod_val, x_synth, p)
          na_level <- which(is.na(levels(predicted)))
          predicted[!predicted %in% (levels(predicted)[-na_level])] <- NA
          predicted <- factor(predicted, exclude = levels(predicted)[na_level])
          synth_l[[j]][[var_id]] <- predicted
        }
        else if(hasNA) {
          pred_NA <- predict.gbm_custom(mod_NA, x_synth, p)
          x_synth_red <- x_synth[pred_NA == FALSE, ]
          pred_val <- predict.gbm_custom(mod_val, x_synth_red, p)
          predicted <- pred_NA
          predicted[pred_NA == FALSE] <- pred_val
          predicted[pred_NA == TRUE] <- NA
          predicted <- as.numeric(predicted)
          synth_l[[j]][[var_id]] <- predicted
        }
        else {
          predicted <- predict.gbm_custom(mod_val, x_synth, p)
          synth_l[[j]][[var_id]] <- predicted
        }
      }
    }
  }
  for(i in seq_along(synth_l)) rownames(synth_l[[i]]) <- NULL
  if(m == 1) synth_l <- synth_l[[1]]
  return(list(syn = synth_l, gen_mods = gen_mods_c))
}


gbm_custom <- function(formula, data, ntrees = 100, ninteractions = 4, shrinkage = 0.1, pdrop = 0, b = nrow(data), loss = "L1") { #TODO surrogate
  controls <- rpart::rpart.control(maxdepth = ninteractions, minbucket = 1, maxcompete = 0, maxsurrogate = 0, xval = 0, cp = 0)
  dep_var <- all.vars(formula)[1]
  indep_vars <- all.vars(formula)[-1]
  if(indep_vars == ".") indep_vars <- colnames(data)[colnames(data) != dep_var]
  y <- data[, dep_var]
  x <- data[, indep_vars, drop = FALSE]
  reg <- !is.factor(y) #regression
  if(!reg) b <- nrow(data) #TODO

  if(reg) {
    if(loss == "L1") initF <- median(y)
    else if(loss == "L2") initF <- mean(y)
    Fi <- rep(initF, length(y))
  }
  else {
    y_ids <- as.data.frame(model.matrix(~ y - 1)) #TODO efficacité : une variable peut être omise
    ncat <- ncol(y_ids)
    class_probs <- colMeans(y_ids)
    initF <- log(colMeans(y_ids))
    Fi <- matrix(rep(initF, each = nrow(data)), nrow = nrow(data), ncol = ncat)
  }

  L_func <- function(y_obs, y_pred) {
    if(reg) {
      if(loss == "L1") return(mean(abs(y_obs - y_pred)))
      else if(loss == "L2") return(mean(0.5 * (y_obs - y_pred)^2))
    }
    else {
      exp_Fi <- exp(y_pred)
      p_mat <- exp_Fi / rowSums(exp_Fi)
      return(-sum(colSums(y_obs * log(p_mat))))
    }
  }

  get_resids <- function(y_obs, y_pred) {
    if(loss == "L1") return(sign(y_obs - y_pred))
    else if(loss == "L2") return(y_obs - y_pred)
  }

  get_med_rows <- function(y_vals, Fi_vals, b_val) {
    if(b_val == nrow(data)) return(1:nrow(data))
    K <- if(reg) floor(length(y_vals) / b_val) else floor(nrow(y_vals) / b_val)
    l_res <- numeric(K)
    shuffled_ids <- if(reg) sample(seq_along(y_vals)) else sample(1:nrow(y_vals))

    if(reg) {
      y_vals <- y_vals[shuffled_ids]
      Fi_vals <- Fi_vals[shuffled_ids]

      for(i in 1:K) {
        idx_start <- (i - 1) * b_val + 1
        idx_end <- i * b_val
        y_sub <- y_vals[idx_start:idx_end]
        Fi_sub <- Fi_vals[idx_start:idx_end]
        l_res[i] <- L_func(y_sub, Fi_sub)
      }
    }
    else {
      y_vals <- y_vals[shuffled_ids, ]
      Fi_vals <- Fi_vals[shuffled_ids, ]

      for(i in 1:K) {
        idx_start <- (i - 1) * b_val + 1
        idx_end <- i * b_val
        y_sub <- y_vals[idx_start:idx_end, ]
        Fi_sub <- Fi_vals[idx_start:idx_end, ]
        l_res[i] <- L_func(y_sub, Fi_sub)
      }
    }
    med_block_id <- which.min(abs(l_res - median(l_res)))
    idx_start <- (med_block_id - 1) * b_val + 1
    idx_end <- med_block_id * b_val
    return(shuffled_ids[idx_start:idx_end])
  }

  mods_l <- list()
  loss_vec <- numeric(ntrees)
  scales <- numeric(ntrees)

  preds_l <- list()
  n_kept <- numeric(length(y))

  get_Fi <- function(ids_l, max_id, overall_Fi) {
    if(length(ids_l) >= max_id) return(overall_Fi)

    if(reg) {
      if(length(ids_l) > 0 && length(ids_l) <= max_id) return(rep(initF, nrow(data)) + Reduce("+", lapply(ids_l, function(j) preds_l[[j]])))
      else return(rep(initF, nrow(data)))
    }
    else {
      Fi <- matrix(rep(initF, each = nrow(data)), nrow = nrow(data), ncol = ncat)
      for(i in ids_l) {
        for(k in 1:ncat) {
          Fi[, k] <- Fi[, k] + preds_l[[i]][[k]]
        }
      }
      return(Fi)
    }
  }

  for(i in 1:ntrees) {
    if(i > 1 && pdrop > 0) {
      M <- rbinom(i - 1, 1, 1 - pdrop)
      if(all(M == 1)) M[sample(seq_along(M), 1)] <- 0
    }
    else M <- rep(1, i-1)

    if(sum(M == 0) > 0) sc <- 1 / (sum(M == 0) + 1)
    else sc <- 1

    scales[i] <- shrinkage * sc
    scales[which(M == 0)] <- scales[which(M == 0)] * sum(M == 0) / (sum(M == 0) + 1)

    Fi_keep <- get_Fi(which(M == 1), i-1, Fi)

    if(reg) {
      med_rows <- get_med_rows(y_vals = y, Fi_vals = Fi, b)
      n_kept[med_rows] <- n_kept[med_rows] + 1

      resids_overall <- get_resids(y, Fi_keep)

      train_data <- data.frame(resids_overall = resids_overall, x)
      train_data <- train_data[med_rows, ]
      model <- rpart::rpart(resids_overall ~ ., data = train_data, control = controls)
      model$train_data <- data.frame(resids_overall = resids_overall, x)
      model$dep_var <- "resids_overall"

      preds_l[[i]] <- scales[i] * predict(model, newdata = data)

      mods_l[[i]] <- model
    }
    else {
      med_rows <- get_med_rows(y_vals = y_ids, Fi_vals = Fi, b)
      n_kept[med_rows] <- n_kept[med_rows] + 1

      exp_Fi_keep <- exp(Fi_keep)
      p_mat <- exp_Fi_keep / rowSums(exp_Fi_keep)
      r_mat <- y_ids - p_mat

      cl_models <- list()
      preds_l[[i]] <- list()
      for(k in 1:ncat) {
        r_k <- r_mat[, k]
        train_data <- data.frame(r_k = r_k, x)
        train_data <- train_data[med_rows, ]
        cl_models[[k]] <- rpart::rpart(r_k ~ ., data = train_data, control = controls)
        cl_models[[k]]$train_data <- data.frame(r_k = r_k, x)
        cl_models[[k]]$dep_var <- "r_k"
        preds <- scales[i] * predict(cl_models[[k]], newdata = data)
        preds_l[[i]][[k]] <- preds
        Fi[, k] <- Fi[, k] + preds
      }
      mods_l[[i]] <- cl_models
    }

    if(i > 1) {
      preds_l <- lapply(seq_along(preds_l), function(tree_id) {
        preds <- preds_l[[tree_id]]
        if(tree_id == i) return(preds)
        if(length(M) > 0 && M[tree_id] == 0) {
          if(reg) preds <- preds * (sum(M == 0) / (sum(M == 0) + 1))
          else preds <- lapply(preds, function(k)  k * (sum(M == 0) / (sum(M == 0) + 1)))
        }
        preds
      })
    }

    if(sum(M == 0) > 0) Fi <- get_Fi(1:i, i+1, NULL)
    else {
      if(reg) Fi <- Fi + preds_l[[i]]
      else {
        for(k in 1:ncat) {
          Fi[, k] <- Fi[, k] + preds_l[[i]][[k]]
        }
      }
    }
  }

  for(i in 1:ntrees) {
    Fi <- get_Fi(1:i, i+1, NULL)
    if(reg) loss_vec[i] <- L_func(y, Fi)
    else loss_vec[i] <- L_func(y_ids, Fi)
  }

  if(b < nrow(data)) {
    id_min_loss <- which.min(loss_vec)
    if(id_min_loss < ntrees) mods_l <- mods_l[1:(id_min_loss-1)]
  }

  if(length(loss_vec) < length(mods_l) + 1) { # compute last loss value # TODO : nécessaire ?
    if(reg) loss_vec[length(loss_vec) + 1] <- L_func(y, Fi)
    else loss_vec[length(loss_vec) + 1] <- L_func(y_ids, Fi)
  }

  if(b < nrow(data)) data <- data[-which(n_kept == 0), ] #TODO

  init_obj <- list(reg = reg,
                   initF = initF,
                   models = mods_l,
                   scales = scales,
                   dep_var = dep_var,
                   fit = Fi,
                   loss_vec = loss_vec,
                   train_data = data)

  where <- predict.gbm_custom(init_obj, data, stochastic = FALSE)

  return(c(init_obj, list(where = where)))
}

predict.gbm_custom <- function(model, newdata, p = 0, stochastic = TRUE) {
  if(is.vector(newdata)) newdata <- data.frame(t(newdata))
  orig <- model$train_data
  models <- model$models

  pred_det <- function(data) {
    if(model$reg) {
      pred <- model$initF
      for(i in seq_along(models)) {
        pred <- pred + predict(object = models[[i]], newdata = data) * model$scales[i]
      }
      return(pred)
    }
    else {
      Fi <- matrix(rep(model$initF, each = nrow(data)), nrow = nrow(data), ncol = length(models[[1]]))
      for (i in seq_along(models)) {
        for (k in seq_along(models[[i]])) {
          Fi[, k] <- Fi[, k] + predict(object = models[[i]][[k]], newdata = data) * model$scales[i]
        }
      }
      exp_Fi <- exp(Fi)
      p_mat <- exp_Fi / rowSums(exp_Fi)
      return(p_mat)
    }
  }

  if(!stochastic && model$reg) return(pred_det(newdata))
  else if(!stochastic) return(unique(orig[, model$dep_var])[max.col(pred_det(newdata))])
  else {
    preds_new <- pred_det(newdata)
    if(model$reg) {
      preds_orig <- model$where
      C <- as.matrix(outer(preds_new, preds_orig, function(x, y) abs(x-y)))
      C <- t(apply(C, 1, function(x) {
        if(p == 0) return(ifelse(x == min(x), 1, 0))
        #else return(ifelse(x %in% sort(x, decreasing = FALSE)[1:as.integer(p*nrow(orig))], 1/(x + 1), 0))
        else return(ifelse(x %in% sort(x, decreasing = FALSE)[1:as.integer(p*nrow(orig))], 1, 0))
      }))
      ids <- apply(C, 1, function(row) sample(seq_along(row), size = 1, prob = row))
      return(orig[ids, model$dep_var])
    }
    else {
      result <- apply(preds_new, 1, function(x) {
        x <- x * (1 - p) + rep(p, length(x))
        sel <- sample(seq_along(x), size = 1, prob = x)
        levels(orig[, model$dep_var])[sel]
      })

      result <- factor(result, levels = levels(orig[, model$dep_var]), exclude = NULL)
      return(result)
    }
  }
}
