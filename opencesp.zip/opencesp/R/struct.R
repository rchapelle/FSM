#' Dependency order in a data set
#'
#' @description
#' `get_dep_order` returns the order of variables associated with the highest log-likelihood, determined using
#' C-vine copula based modeling.
#'
#' @param pseudo_df A dataframe containing pseudo-observations suited to copula based modeling.
#' @param blocks A numerical vector containing indexes of independent variable blocks. If set to NULL,
#' only one cluster is considered, containing all variables of `pseudo_df`.
#'
#' @return A numerical vector representing the order of dependency.
get_dep_order <- function(df, blocks = NULL, method = "fit-hclust", vines.n_cores = NULL, bn.restart = 1000, bn.perturb = 1000, fit.n_per = 100, fit.n_starts = 20, fit.n_cores = NULL, fit.bf_first = TRUE, ...) {
  if(!method %in% c("bn", "vines", "fit-hclust", "fit")) stop("Method must be one of (\"bn\", \"vines\", \"fit\").")
  if(method %in% c("bn", "vines")) df <- data.frame(lapply(df, function(x) as.numeric(x)))

  if(is.null(blocks)) blocks <- rep(1, ncol(df))
  res <- rep(NA, length(blocks))
  shift <- 0

  for(cl in 1:max(blocks)) {
    blocks_indices <- which(blocks == cl)
    if(length(blocks_indices) <= 2) {
      res[blocks_indices] <- 1:length(blocks_indices) + shift
    }
    else {
      reduced_df <- df[, blocks_indices, drop = FALSE]

      if(method == "bn") {
        score <- "loglik-cg"
        if(all(sapply(df, is.numeric))) score <- "loglik-g" #TODO documentation
        else if(all(sapply(df, is.factor))) score <- "loglik"
        bn <- bnlearn::hc(reduced_df, score = score, restart = bn.restart, perturb = bn.perturb)
        best <- match(bnlearn::node.ordering(bn), names(reduced_df))
      }
      else if(method == "vines") best <- rev(as.integer(VineCopula::RVineStructureSelect(VineCopula::pobs(reduced_df), type=1, selectioncrit = "logLik", cores = vines.n_cores)$Matrix[, 1]))
      else if(method == "fit-hclust") {
        if(!fit.bf_first || "priority" %in% names(list(...))) best <- hclust_fit_order(reduced_df, n_cores = fit.n_cores, ...)$order
        else {
          scores <- numeric(ncol(reduced_df))
          orders <- list()
          for(j in 1:ncol(reduced_df)) {
            ord <- hclust_fit_order(reduced_df, n_cores = fit.n_cores, priority = c(j), ...)$order
            orders[[length(orders) + 1]] <- ord
            scores[j] <- get_fit_score(reduced_df, ord, score_cart, mb= synth_mb)
          }
          best <- orders[[which.max(scores)]]
        }
      }
      else { # fit
        args <- list(...)
        best <- hc(
          start_func = function() get_rand_orders(ncol(reduced_df), 1)[[1]],
          per_func = function(x) {
            swap <-  sample(length(x), 2)
            x[swap] <- x[rev(swap)]
            return(x)
          },
          score_func = function(x) do.call(get_fit_score, c(list(reduced_df, x), args)),
          n_per = fit.n_per,
          n_starts = fit.n_starts,
          n_cores = fit.n_cores
        )$val
      }

       res[(shift+1):(shift+length(best))] <- blocks_indices[best]

    }
    shift <- shift + length(blocks_indices)
  }


  return(res)
}



#' TODO
get_fit_score <- function(df, order, score_func, base_score = NULL, base_l = 0, ...) { #TODO normalize = TRUE
  df <- df[, order, drop = FALSE]

  scores <- if(base_l == 0) numeric(ncol(df) - 1) else numeric(ncol(df) - base_l)

  if(length(scores) > 0) {
    start <- ifelse(base_l == 0, 2, base_l + 1)
    curr <- 1

    for(i in start:ncol(df)) {
      dep <- df[, i]
      scores[curr] <- score_func(dep, df[, 1:(i-1)], ...)
      curr <- curr + 1
    }
  }

  x_mean <- function(x) {
    sum(x) / ncol(df)
  }

  if(is.null(base_score)) {
    first_score <- score_func(df[, 1], NULL, ...)
    return(x_mean(c(first_score, scores)))
  }
  else return(x_mean(c(base_score * base_l, scores)))
}

#' TODO
hc <- function(start_func, per_func, score_func, n_per = 100, n_starts = 1, n_cores = NULL) {
  if(is.null(n_cores)) n_cores <- parallelly::availableCores() - 1

  process <- function(n) {
    glob_val <- NULL
    for(i in 1:n) {
      val <- start_func()
      score <- score_func(val)
      for(j in 1:n_per) {
        new_val <- per_func(val)
        new_score <- score_func(new_val)
        if(new_score > score) {
          val <- new_val
          score <- new_score
        }
      }
      if(is.null(glob_val) || score_func(val) > score_func(glob_val)) glob_val <- val
    }
    return(list(val = glob_val, score = score_func(glob_val)))
  }

  if(n_cores > 1) {
    future::plan(future_strategy(), workers = n_cores)
    lists <- future.apply::future_lapply(get_chunks(n_starts, n_cores), process, future.seed = TRUE)
    future::plan(future::sequential)
    return(lists[[which.max(sapply(lists, function(x) x$score))]])
  }
  else return(process(n_starts))
}



hclust_base <- function(df, sim_func, n_bf = 1, sym = FALSE, n_cores = NULL) {
  if(is.null(n_cores)) n_cores <- parallelly::availableCores() - 1

  colnames(df) <- seq_along(df)

  merge_history <- matrix(0, ncol = 2, nrow = 0)
  clust_ids <- -seq_len(ncol(df))
  current_clust <- 0

  cl_set <- list()
  for(i in 1:ncol(df)) {
    cl_set[[i]] <- df[, i, drop = FALSE]
  }

  future::plan(future_strategy(), workers = n_cores)

  while(length(cl_set) > n_bf) {
    sim_mat <- matrix(-Inf, nrow = length(cl_set), ncol = length(cl_set))

    ids <- expand.grid(1:length(cl_set), 1:length(cl_set))
    ids <- ids[ids$Var1 != ids$Var2, ]

    sims <- future.apply::future_lapply(1:nrow(ids), function(k) {
      i <- ids[k, 1]
      j <- ids[k, 2]
      if(!sym || i < j) sim_func(cl_set[[i]], cl_set[[j]])
      else -Inf
    }, future.seed = NULL) # no randomness involved but this prevents erroneous error messages from the future package.

    for(k in 1:nrow(ids)) {
      i <- ids[k, 1]
      j <- ids[k, 2]
      sim_mat[i, j] <- sims[[k]]
    }

    if(all(sim_mat == -Inf)) break

    idx <- which(sim_mat == max(sim_mat), arr.ind = TRUE)[1, ]

    current_clust <- current_clust + 1
    merge_history <- rbind(merge_history, clust_ids[idx])

    new_cl <- cbind(cl_set[[idx[1]]], cl_set[[idx[2]]])
    cl_set <- cl_set[-c(idx[1], idx[2])]
    cl_set[[length(cl_set) + 1]] <- new_cl

    clust_ids <- c(clust_ids[-c(idx[1], idx[2])], current_clust)
  }

  future::plan(future::sequential)

  hc_obj <- list(merge = merge_history, order = as.numeric(colnames(cl_set[[1]])), height = 1:nrow(merge_history))
  class(hc_obj) <- "hclust"

  return(list(merge_history = merge_history, clusters = cl_set, clusters_ids = clust_ids, hc_obj = hc_obj))
}


#' TODO
hclust_fit_order <- function(df, score_func, priority = NULL, n_bf = 1, n_cores = NULL, ...) {
  ellipsis <- list(...)
  fs_cache <- fastmap::fastmap()

  get_sim <- function(cl1, cl2) {
    cl_all <- c(colnames(cl1), colnames(cl2))
    key <- paste(cl_all, collapse = "_")

    if(fs_cache$has(key)) return(fs_cache$get(key))
    else {
      largest <- NULL
      largest_l <- 0

      for(i in (length(cl_all)-1):1) {
        ckey <- paste(cl_all[1:i], collapse = "_")
        if(fs_cache$has(ckey)) {
          largest_l <- i
          largest <- fs_cache$get(ckey)
          break
        }
      }

      fs <- do.call(get_fit_score, c(list(cbind(cl1, cl2), 1:(ncol(cl1) + ncol(cl2)), score_func, base_score = largest, base_l = largest_l), ellipsis))

      fs_cache$set(key, fs)
      return(fs)
    }
  }

  if(is.null(priority) || length(priority) == 0) res_hc <- hclust_base(df, get_sim, n_bf = n_bf, sym = FALSE, n_cores = n_cores)
  else {
    first_part <- as.numeric(colnames(hclust_base(df[, priority, drop = FALSE], get_sim, n_bf = 1, sym = FALSE, n_cores = n_cores)$clusters[[1]]))
    first_part <- priority[first_part]
    get_sim_priority <- function(cl1, cl2) {
      get_sim(cbind(df[, first_part], cl1), cl2)
    }
    second_part <- as.numeric(colnames(hclust_base(df[, setdiff(1:ncol(df), priority)], get_sim_priority, n_bf = 1, sym = FALSE, n_cores = n_cores)$clusters[[1]]))
    second_part <- setdiff(1:ncol(df), priority)[second_part]
    return(list(hc_obj = NULL, order = c(first_part, second_part)))
  }

  if(n_bf == 1) order <- as.numeric(colnames(res_hc$clusters[[1]]))
  else {
    all_perms <- gtools::permutations(n = length(res_hc$clusters), r = length(res_hc$clusters))
    all_perms <- split(all_perms, seq(nrow(all_perms)))

    get_sim_perm <- function(cls, perm) {
      get_sim(cls[[perm[1]]], cls[[perm[2]]])  #allow to populate the cache
      curr_cl <- cbind(cls[[perm[1]]], cls[[perm[2]]])
      if(length(perm) > 3) {
        for(i in 3:(length(perm)-1)) {
          get_sim(curr_cl, cls[[perm[i]]])
          curr_cl <- cbind(curr_cl, cls[[perm[i]]])
        }
      }
      return(get_sim(curr_cl, cls[[perm[length(perm)]]]))
    }

    future::plan(future_strategy(), workers = n_cores)

    res_bf <- future.apply::future_sapply(all_perms, function(perm) {
      get_sim_perm(res_hc$clusters, perm)
    }, future.seed = NULL) # no randomness involved but this prevents erroneous error messages from the future package.

    future::plan(future::sequential)

    best_perm <- all_perms[[which.max(res_bf)]]
    order <- numeric(ncol(df))
    thr <- 0
    for(id in best_perm) {
      order[(1:ncol(res_hc$clusters[[id]])) + thr] <- as.numeric(colnames(res_hc$clusters[[id]]))
      thr <- thr + ncol(res_hc$clusters[[id]])
    }

    old_merge <- res_hc$hc_obj$merge
    m0 <- nrow(old_merge)
    clust_ids <- res_hc$clusters_ids
    new_merge <- matrix(0, ncol = 2, nrow = length(best_perm) - 1)
    for(i in seq_len(nrow(new_merge))) {
      m0 <- m0 + 1
      new_merge[i, ] <- c(clust_ids[best_perm[i]], clust_ids[best_perm[i + 1]] )
      clust_ids[best_perm[i + 1]] <- m0
    }
    res_hc$hc_obj$merge <- rbind(old_merge, new_merge)
    res_hc$hc_obj$height <- seq_len(nrow(res_hc$hc_obj$merge))
    res_hc$hc_obj$order <- order
  }

  return(list(hc_obj = res_hc$hc_obj, order = order))
}



#' TODO
get_ind_blocks <- function(df, max_size = ncol(df)/2, n_cores = NULL) {
  h_cache <- fastmap::fastmap()

  get_h <- function(cl) {
    key <- paste(colnames(cl), collapse = "_")
    if (h_cache$has(key)) return(h_cache$get(key))
    num_mat <- as.matrix(cl[, sapply(cl, is.numeric)])
    qual_mat <- as.matrix(cl[, sapply(cl, function(x) is.factor(x) || is.character(x))])
    if(ncol(qual_mat) == 0) Z <- PCAmixdata::recod(num_mat, NULL, rename.level = TRUE)$Z
    else if(ncol(num_mat) == 0) Z <- PCAmixdata::recod(NULL, qual_mat, rename.level = TRUE)$Z
    else Z <- PCAmixdata::recod(num_mat, qual_mat, rename.level = TRUE)$Z
    e <- svd(Z/sqrt(nrow(Z)))
    h_cache$set(key, e$d[1])
    return(e$d[1])
  }

  get_sim <- function(cl1, cl2) {
    if(ncol(cl1) + ncol(cl2) > max_size) return(-Inf)
    return(get_h(cbind(cl1, cl2)) - get_h(cl1) - get_h(cl2))
  }

  res_hc <- hclust_base(df, get_sim, sym = TRUE, n_cores = n_cores)

  cvec <- numeric(ncol(df))

  for (i in seq_along(res_hc$clusters)) {
    cvec[as.numeric(colnames(res_hc$clusters[[i]]))] <- i
  }

  return(cvec)
}



#' TODO
bn_from_order <- function(data, order) {
  nodes <- colnames(data)[order]
  arcs <- matrix(ncol = 2, nrow = ncol(data) - 1)
  for (i in 1:(ncol(data) - 1)) {
    arcs[i, ] <- c(nodes[i], nodes[i + 1])
  }
  bn <- bnlearn::empty.graph(nodes = nodes)
  bnlearn::arcs(bn) <- arcs
  return(bn)
}



#' C-vine associated with a given dependency order
#'
#' @description
#' `vine_from_order` returns the C-vine maximizing the log-likelihood, while respecting a
#' specified order of the tree roots.
#'
#' @param df A dataframe containing pseudo-observations suited to copula based modeling. #TODO pseudo
#' @param order A numerical vector containing the desired order.
#' @param n_cores The number of logical processes to use for the computation. If set to NULL, the function will
#' attempt to determine the number of physical cores on the device and use this number, minus one.
#'
#' @return A `RVineMatrix()` object (see [MASS::VineCopula()]).
vine_from_order <- function(df, order, n_cores = NULL) {
  if(is.null(n_cores)) n_cores <- parallelly::availableCores() - 1

  get_mat <- function(order) {
    order <- rev(order)
    d <- length(order)
    structure_matrix <- matrix(0, nrow = d, ncol = d)
    structure_matrix[, 1] <- order
    for (i in 2:d) {
      structure_matrix[i:d, i] <- order[i:d]
    }
    return(structure_matrix)
  }

  pseudo_df <- VineCopula::pobs(df)

  return(VineCopula::RVineCopSelect(pseudo_df, Matrix=get_mat(order), selectioncrit = "logLik", cores = n_cores))
}
