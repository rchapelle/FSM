#' Load embedded datasets
#'
#' @description
#' `load_data` loads datasets provided with the package as global dataframes. In the loaded dataframes, ordinal variables are typed as factors.
#'
#' @param names The name of a dataset, or a vector of dataset names. If set to NULL, the function will load every datasets embedded with the package.
load_data <- function(names=NULL) {
  path <- system.file("extdata", package = "opencesp")
  files <- list.files(path = path, pattern = "\\.rds$", full.names = TRUE, recursive = TRUE)

  if(is.null(names)) names <- tools::file_path_sans_ext(basename(files))
  else if (is.character(names) && length(names) == 1) names <- c(names)

  find_rds <- function(names) {
    target_file <- files[basename(files) == paste0(names, ".rds")]
    if (length(target_file) > 0) return(target_file)
    else return(NA)
  }

  res_files <- lapply(names, find_rds)
  res_files <- unlist(res_files)
  res_files <- res_files[!is.na(res_files)]

  for(file in res_files) {
    assign(tools::file_path_sans_ext(basename(file)), readRDS(file), envir = .GlobalEnv)
  }
}



#' TODO
get_sim_data <- function(n_obs, n_vars, func = rnorm, ...) {
  df <- data.frame(Var.1 = do.call(func, list(n_obs)))
  if(n_vars > 1) {
    for(i in 2:n_vars) {
      coefs <- runif(i-1, min = -1, max = 1)
      if (i == 2) df[, i] <- df[, 1] * coefs
      else df[, i] <- as.vector(as.matrix(df[, 1:(i-1)]) %*% coefs)
      df[, i] <- df[, i] / sd(df[, i])
      df[, i] <- df[, i] + do.call(func, list(n_obs, ...))
    }
  }
  colnames(df) <- seq_along(df)
  return(df)
}



#' TODO
impute_rf <- function(df, ...) {
  if(anyNA(df)) {
    orig_names <- colnames(df) # Allows using numbers as column names
    colnames(df) <- paste0("Var.", colnames(df))
    imputed <- mice::mice(df, method = "rf", printFlag = FALSE, ...)
    res <- mice::complete(imputed)
    colnames(res) <- orig_names
    return(res)
  }
  else {
    warning("Nothing to impute.")
    return(df)
  }
}



#' TODO
normalize_df <- function(df) {
  norms <- list()
  for(i in seq_along(df)) {
    if(is.numeric(df[, i])) {
      norm <- bestNormalize(df[, i])
      df[, i] <- norm$x.t
      norms[[i]] <- norm
    }
  }
  return(list(df = df, norms = norms))
}



#' TODO
get_rand_orders <- function(n_vars, n_orders) {
  rand_orders <- list()
  while (length(rand_orders) < n_orders) {
    perm <- sample(1:n_vars)
    if (!any(sapply(rand_orders, function(x) all(x == perm)))) {
      rand_orders <- append(rand_orders, list(perm))
    }
  }
  return(rand_orders)
}



#' Partition an integer into nearly equal parts
#'
#' @description
#' `get_chunks` partitions an integer `n` into `m` nearly equal parts such that
#' the sum of these parts is exactly `n`.
#'
#' @param n An integer, the total quantity to be divided.
#' @param m An integer, the number of parts to divide `n` into.
#'
#' @return A numeric vector of length `m` containing the resulting parts.
get_chunks <- function(n, m) {
  base_part <- n %/% m
  remainder <- n %% m
  parts <- rep(base_part, m)
  if(remainder > 0) {
    for (i in 1:remainder) {
      parts[i] <- parts[i] + 1
    }
  }
  return(parts)
}



#' TODO
quiet <- function(x) {
  sink(tempfile())
  on.exit(sink())
  invisible(force(x))
}



#' TODO
future_strategy <- function() {
  if(parallelly::supportsMulticore()) return(future::multicore)
  else return(future::multisession)
}



#' TODO
get_prec <- function(vec, max = TRUE) {
  prec_vec <- sapply(vec, function(x) {
    if (is.na(x)) NA
    else {
      s <- as.character(x)
      if (grepl("\\.", s)) nchar(sub(".*\\.", "", s))
      else 0
    }
  })
  if(max) return(max(prec_vec, na.rm = TRUE))
  else return(prec_vec)
}



#' TODO
get_int_prop <- function(vec) {
  vec <- vec[!is.na(vec)]
  if(length(vec) == 0)  return(NA)
  n_int <- sum(vec%%1==0)
  return(n_int / length(vec))
}


#' TODO
csample <- function(vec, ...) {
  if(length(vec) > 1) return(sample(vec, ...))
  else return(vec[1])
}
