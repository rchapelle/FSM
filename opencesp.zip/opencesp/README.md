# Private repository of the Open-CESP team

See the [introductory paper](https://hal.science/hal-04233955/document) to this work.


## Requirements

- Valid R > 4 and Python > 3.7 environments.
- R dependencies listed in the DESCRIPTION file.
- [Anonymeter](https://github.com/statice/anonymeter) installed on the Python environment to use with the package.
## Installation

The repository contains a R package which can be installed from source using the following commands:

```bash
  cd path/to/the/root/dir
  R CMD BUILD opencesp
  R CMD INSTALL opencesp_<version name>.tar.gz
```
## Usage/Examples

The Example directory contains two example scripts. The Example/RU_maps.R script plots a Utility-Risk profile for two specific metrics implemented in the package, namely the CI overlap and the corrected F1 metric.

![image info](examples/UR-plot.png)
